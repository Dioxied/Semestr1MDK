﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace evaluations
{
    public enum Ocenki
    {
        none, One , Two , Three , Four , Five 
    }
}
